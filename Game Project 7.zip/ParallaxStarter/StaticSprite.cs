﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace ParallaxStarter
{
    public class StaticSprite : ISprite
    {
        public Vector2 position = Vector2.Zero;
        Texture2D texture;

        public StaticSprite(Texture2D t)
        {
            texture = t;
        }

        public StaticSprite(Texture2D t, Vector2 pos)
        {
            texture = t;
            position = pos;
        }

        public void Draw(SpriteBatch spriteBatch, GameTime gameTime)
        {
            spriteBatch.Draw(texture, position, Color.White);
        }
    }
}
