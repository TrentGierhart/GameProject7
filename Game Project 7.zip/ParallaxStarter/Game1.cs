﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System.Collections.Generic;

namespace ParallaxStarter
{
    /// <summary>
    /// This is the main type for your game.
    /// </summary>
    public class Game1 : Game
    {
        GraphicsDeviceManager graphics;
        SpriteBatch spriteBatch;


        Player player;

        public Game1()
        {
            graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
        }

        /// <summary>
        /// Allows the game to perform any initialization it needs to before starting to run.
        /// This is where it can query for any required services and load any non-graphic
        /// related content.  Calling base.Initialize will enumerate through any components
        /// and initialize them as well.
        /// </summary>
        protected override void Initialize()
        {
            // TODO: Add your initialization logic here

            base.Initialize();
        }

        /// <summary>
        /// LoadContent will be called once per game and is the place to load
        /// all of your content.
        /// </summary>
        protected override void LoadContent()
        {
            // Create a new SpriteBatch, which can be used to draw textures.
            spriteBatch = new SpriteBatch(GraphicsDevice);

            // TODO: use this.Content to load your game content here
            //player
            var spritesheet = Content.Load<Texture2D>("player");
            player = new Player(spritesheet);
            ParallaxLayer PlayerLayer = new ParallaxLayer(this);
            PlayerLayer.Sprites.Add(player);
            PlayerLayer.DrawOrder = 2;
            PlayerLayer.ScrollController = new PlayerTrackingScrollController(player, 1.0f);
            Components.Add(PlayerLayer);

            //foreground
            List<Texture2D> foregroundTextures = new List<Texture2D>()
            {
                Content.Load<Texture2D>("foreground21"),
                Content.Load<Texture2D>("foreground22"),
                Content.Load<Texture2D>("foreground23"),
                Content.Load<Texture2D>("foreground24")
            };
            List<StaticSprite> foregroundSprites = new List<StaticSprite>();
            for (int i = 0; i < foregroundTextures.Count; i++)
            {
                Vector2 pos = new Vector2(3500 * i, 0);
                StaticSprite sprite = new StaticSprite(foregroundTextures[i], pos);
                foregroundSprites.Add(sprite);
            }
            ParallaxLayer foregroundLayer = new ParallaxLayer(this);
            foreach (var sprite in foregroundSprites)
            {
                foregroundLayer.Sprites.Add(sprite);
            }
            foregroundLayer.DrawOrder = 4;
            foregroundLayer.ScrollController = new PlayerTrackingScrollController(player, 1.0f);
            Components.Add(foregroundLayer);

            //midground
            Texture2D[] midgroundTextures = new Texture2D[]
            {
                Content.Load<Texture2D>("midground21"),
                Content.Load<Texture2D>("midground22")
            };
            StaticSprite[] midgroundSprites = new StaticSprite[]
            {
                new StaticSprite(midgroundTextures[0]),
                new StaticSprite(midgroundTextures[1], new Vector2(3500, 0))
            };
            ParallaxLayer midgroundLayer = new ParallaxLayer(this);
            midgroundLayer.Sprites.AddRange(midgroundSprites);
            midgroundLayer.DrawOrder = 1;
            midgroundLayer.ScrollController = new PlayerTrackingScrollController(player, 0.4f);
            Components.Add(midgroundLayer);

            //background
            Texture2D backgroundTexture = Content.Load<Texture2D>("background2");
            StaticSprite backgroundSprite = new StaticSprite(backgroundTexture);
            ParallaxLayer backgroundLayer = new ParallaxLayer(this);
            backgroundLayer.Sprites.Add(backgroundSprite);
            backgroundLayer.DrawOrder = 0;
            backgroundLayer.ScrollController = new PlayerTrackingScrollController(player, 0.1f);
            Components.Add(backgroundLayer);
        }

        /// <summary>
        /// UnloadContent will be called once per game and is the place to unload
        /// game-specific content.
        /// </summary>
        protected override void UnloadContent()
        {
            // TODO: Unload any non ContentManager content here
        }

        /// <summary>
        /// Allows the game to run logic such as updating the world,
        /// checking for collisions, gathering input, and playing audio.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Update(GameTime gameTime)
        {
            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed || Keyboard.GetState().IsKeyDown(Keys.Escape))
                Exit();

            // TODO: Add your update logic here
            player.Update(gameTime);

            base.Update(gameTime);
        }

        /// <summary>
        /// This is called when the game should draw itself.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.CornflowerBlue);

            // TODO: Add your drawing code here


            base.Draw(gameTime);
        }
    }
}
