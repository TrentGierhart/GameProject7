﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace ParallaxStarter
{
    public interface ISprite
    {
        void Draw(SpriteBatch spriteBatch, GameTime gameTime);
    }
}
