﻿using Microsoft.Xna.Framework;

namespace ParallaxStarter
{
    public interface IScrollController
    {
        Matrix Transform { get; }

        void Update(GameTime gameTime);
    }
}
